package baseDatos;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.PrintStream;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;

import clases.Alumnos;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;


public class Sentencias {
	
	private static Conexion bd;
	
	//Profesores
	public static boolean registroProfesores(String dni, String contrasena){
		
		String sql = "SELECT * FROM fichajeAlumnos_profesores WHERE (dni LIKE ? AND contrase�a LIKE ?)";
		Conexion bd = new Conexion(sql);
		bd.setString(1, dni);
		bd.setString(2, contrasena);
		ResultSet rs = bd.executeQuery();
		try {
			while(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	public static String getProfesores() {
		
			String sql = "SELECT * FROM fichajeAlumnos_profesores";
			bd = new Conexion(sql);
			ResultSet rs = bd.executeQuery();
			return parseProfesor(rs);
		
	}
	private static String parseProfesor(ResultSet rs) {
		StringBuffer sb = new StringBuffer();
		try {
			while (rs.next()) {
				sb.append("<span>" + rs.getString("dni") + "</span><br>");
				sb.append("<span>" + rs.getString("contrase�a") + "</span><br><br>>");
			}
		} catch (Exception e) {
			System.out.println("Error en parseProfesor");
		}
		return sb.toString();
	}
	
	//Ciclos
	public static String getCiclos(String dni) {
		
		String sql = "SELECT * FROM fichajeAlumnos_puedencrear WHERE (dni LIKE ?)";
		bd = new Conexion(sql);
		bd.setString(1, dni);
		ResultSet rs = bd.executeQuery();
		return parseCiclos(rs);
	
	}
	private static String parseCiclos(ResultSet rs) {
		StringBuffer sb = new StringBuffer();
		try {
			while (rs.next()) {
				sb.append("<div class=boton><a href=ciclo.do class=botoncito><span class=ciclo>" + rs.getString("idCiclo") + "</span></a></div>"); 
			}
		} catch (Exception e) {
			System.out.println("Error en parseCiclos");
		}
		return sb.toString();
	}
	public static void agregarCiclo(String nombre, String idCiclo, String dni){
		String sql = "INSERT INTO fichajeAlumnos_ciclos VALUES (?, ?)";
		bd = new Conexion(sql);
		bd.setString(1, idCiclo);
		bd.setString(2, nombre);
		bd.executeUpdate();
		insertarPuedenCrear(idCiclo, dni);
	}
	private static void insertarPuedenCrear(String idCiclo, String dni){
		
		String sql = "INSERT INTO fichajeAlumnos_puedencrear VALUES (?, ?)";
		bd = new Conexion(sql);
		bd.setString(1, dni);
		bd.setString(2, idCiclo);
		bd.executeUpdate();
	}
	public static boolean eliminarCiclo(String idCiclo){
		
		String sql = "DELETE FROM fichajeAlumnos_ciclos WHERE idCiclo LIKE ?";
			
		Conexion bd = new Conexion(sql);
		bd.setString(1, idCiclo);
		bd.executeUpdate();
		
		int numRows = bd.executeUpdate();
		if (numRows == 0)
			return true;
		else
			return false;
	}
	
	//Modulos
	public static String getModulos(String idCiclo) {
		
		String sql = "SELECT * FROM fichajeAlumnos_hay WHERE (idCiclo LIKE ?)";
		bd = new Conexion(sql);
		bd.setString(1, idCiclo);
		ResultSet rs = bd.executeQuery();
		return parseModulos(rs);	
	}
	private static String parseModulos(ResultSet rs) {
		StringBuffer sb = new StringBuffer();
		try {
			while (rs.next()) {
				
				sb.append("<div class=boton><a href=modulo.do class=botoncito><span class=modulo>" + rs.getString("idModulo") + "</span></a></div>"); 
			}
		} catch (Exception e) {
			System.out.println("Error en parseModulos");
		}
		return sb.toString();
	}
	public static void agregarModulo(String nombre, String idModulo, String idCiclo){
		String sql = "INSERT INTO fichajeAlumnos_modulos VALUES (?, ?)";
		bd = new Conexion(sql);
		bd.setString(1, idModulo);
		bd.setString(2, nombre);
		bd.executeUpdate();
		insertarHay(idCiclo, idModulo);
	}
	private static void insertarHay(String idCiclo, String idModulo){
		
		String sql = "INSERT INTO fichajeAlumnos_hay VALUES (?, ?)";
		bd = new Conexion(sql);
		bd.setString(1, idCiclo);
		bd.setString(2, idModulo);
		bd.executeUpdate();
	}
	public static boolean eliminarModulo(String idModulo){
		
		String sql = "DELETE FROM fichajeAlumnos_modulos WHERE idModulo LIKE ?";
			
		Conexion bd = new Conexion(sql);
		bd.setString(1, idModulo);
		bd.executeUpdate();
		
		int numRows = bd.executeUpdate();
		if (numRows == 0)
			return true;
		else
			return false;
	}

	//Alumnos
	public static boolean registroAlumnos(String dni, String contrasena){
		
		String sql = "SELECT * FROM fichajeAlumnos_alumnos WHERE (dnia LIKE ? AND contrase�a LIKE ?)";
		Conexion bd = new Conexion(sql);
		bd.setString(1, dni);
		bd.setString(2, contrasena);
		ResultSet rs = bd.executeQuery();
		try {
			while(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			System.out.println("Error en registro de alumnos");
		}
		return false;
	}
	public static void ficharAlumno(String ip, String fecha, String hora, String idRegistro){
		String sql = "INSERT INTO fichajeAlumnos_registrodefaltas  VALUES (?, ?, ?, ?, ?)";
		Conexion bd = new Conexion(sql);
		bd.setString(1, idRegistro);
		bd.setInt(2, 0);
		bd.setString(3, fecha);
		bd.setString(4, hora);
		bd.setString(5, ip);
		bd.executeUpdate();
		sql = "UPDATE fichajeAlumnos_alumnos SET idRegistro=?, fr=?, ip=? WHERE dnia LIKE ?";
		bd = new Conexion(sql);
		bd.setString(1, idRegistro);
		bd.setString(2, "si");
		bd.setString(3, ip);
		bd.setString(4, idRegistro);
		bd.executeUpdate();
	}
	public static void fichajeAutomatico (String fecha, String hora){

		try {
			String sql = "SELECT dnia FROM fichajealumnos_alumnos WHERE fr like 'no'";
			bd = new Conexion(sql);
			ResultSet rs = bd.executeQuery();
			while(rs.next()){
				sql = "INSERT INTO fichajealumnos_registrodefaltas (idRegistro, numFaltas, fecha, hora) VALUES (?, ?, ? ,?)";
				bd = new Conexion(sql);
				bd.setString(1, rs.getString("dnia"));
				bd.setInt(2,  1);
				bd.setString(3, fecha);
				bd.setString(4, hora);
				bd.executeUpdate();
				sql = "UPDATE fichajeAlumnos_alumnos SET idRegistro=? WHERE dnia like ?";
				bd = new Conexion(sql);
				bd.setString(1, rs.getString("dnia"));
				bd.setString(2, rs.getString("dnia"));
				bd.executeUpdate();
			}
			sql = "UPDATE fichajeAlumnos_alumnos SET  fr=? ";
			bd = new Conexion(sql);
			bd.setString(1, "no");
			bd.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Error en fichajeAutomatico");
		}
		
	}
	public static String getAlumnos(String idCiclo){
		
		String sql = "SELECT nombre, fr, apellidos FROM fichajeAlumnos_alumnos WHERE (idCiclo LIKE ?)";
		bd = new Conexion(sql);
		bd.setString(1, idCiclo);
		ResultSet rs = bd.executeQuery();
		return parseAlumnos(rs);
	}
	private static String parseAlumnos(ResultSet rs) {
		StringBuffer sb = new StringBuffer();
		try {
			
			while (rs.next()) {
				sb.append("<tr><td>");
				sb.append(rs.getString("nombre") + " ");
				sb.append(rs.getString("apellidos"));
				sb.append("</td><td>");
				if(rs.getString("fr").toString().equals("si"))
					sb.append("<input type=checkbox name=registro value='" + rs.getString("fr") + "' checked>");
				else
					sb.append("<input type=checkbox name=registro value='" + rs.getString("fr") + "'>");
				sb.append("</td></tr>");
			}
		} catch (Exception e) {
			System.out.println("Error en parseAlumnos");
		}
		return sb.toString();
	}
	
	//informe faltas alumnos
	public static void generarInforme(String fini, String ffin, String ruta){
		
		String sql = "SELECT a1.nombre, a1.apellidos, r1.numFaltas FROM fichajeAlumnos_alumnos a1, fichajeAlumnos_registrodefaltas r1   WHERE (a1.idRegistro LIKE r1.idRegistro AND r1.fecha BETWEEN ? AND ?)";
		bd = new Conexion(sql);
		bd.setString(1, fini);
		bd.setString(2, ffin);
		ResultSet rs = bd.executeQuery();
		generarPdf(rs, ruta);
	}
	private static void generarPdf(ResultSet rs, String ruta){
	
		PrintStream out;
	
		try {
			out = new PrintStream(new FileOutputStream(ruta));		
			Document document = new Document();
		
			PdfWriter.getInstance(document, new FileOutputStream(ruta));
			
			document.open();
			PdfPTable table = new PdfPTable(2);
		    PdfPCell cell;
		    cell = new PdfPCell(new Phrase("Alumno"));
		    table.addCell(cell);
		    cell = new PdfPCell(new Phrase("N�mero de faltas"));
		    table.addCell(cell);
		    
		    String actual = "";
		    String anterior = "";
		    String nombre = "";
		    String nombreA = "";
		    boolean primera = true;
		    int contador = 0;
		 
			while (rs.next()) {
				nombre = rs.getString("nombre");
				actual = rs.getString("apellidos");
				if(actual.equals(anterior) && nombre.equals(nombreA)){
					contador = contador + Integer.parseInt(rs.getString("numFaltas"));
				}else{
					if(primera){
						anterior = actual;
						nombreA = nombre;
						contador = 0;
						contador = contador + Integer.parseInt(rs.getString("numFaltas"));
						primera = false;
					}else{
						cell = new PdfPCell(new Phrase(nombreA + " " + anterior));
						table.addCell(cell);
						cell = new PdfPCell(new Phrase(contador + ""));
						table.addCell(cell);
						anterior = actual;
						nombreA = nombre;
						contador = 0;
						contador = contador + Integer.parseInt(rs.getString("numFaltas"));
					}
				}	    
			}
			cell = new PdfPCell(new Phrase(nombreA + " " + anterior));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase(contador + ""));
			table.addCell(cell);
			
			document.add(table);
			document.close();
			out.flush();
		    out.close();
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	//importar lista de alumnos
	public static void Lectura(String ruta, String ciclo) {
		Gson gson = new Gson();
		
		try {
			FileReader fileReader = new FileReader(ruta);
			
			JsonParser jsonParser = new JsonParser();
			JsonElement jsonElement = jsonParser.parse(fileReader);
			JsonArray jsonArray = jsonElement.getAsJsonArray();
			Iterator<JsonElement> iterator = jsonArray.iterator();
			while(iterator.hasNext()){
				
				JsonElement jsonElement1 = iterator.next();
				Alumnos alu = gson.fromJson(jsonElement1, Alumnos.class);
				insertarAlumnos(alu.getNombre(), alu.getApellidos(), alu.getDni(), ciclo);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	private static void insertarAlumnos(String nombre, String apellidos, String dni, String modulo){
		
		String sql = "INSERT INTO fichajeAlumnos_alumnos (dnia, idCiclo, nombre, fr, apellidos)  VALUES (?, ?, ?, ?, ?)";
		Conexion bd = new Conexion(sql);
		bd.setString(1, dni);
		bd.setString(2, modulo);
		bd.setString(3, nombre);
		bd.setString(4, "no");
		bd.setString(5, apellidos);
		bd.executeUpdate();
	}
}