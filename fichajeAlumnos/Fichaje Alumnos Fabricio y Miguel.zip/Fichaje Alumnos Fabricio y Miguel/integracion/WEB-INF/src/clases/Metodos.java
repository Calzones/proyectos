package clases;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;

public class Metodos {
	
	static Temporizador temp = new clases.Temporizador();
	public static void temp(){
		
		Date horaDespertar = new Date(System.currentTimeMillis());
		Calendar c = Calendar.getInstance();
		c.setTime(horaDespertar);
		if (c.get(Calendar.HOUR_OF_DAY) >= 22) {
			c.set(Calendar.DAY_OF_YEAR, c.get(Calendar.DAY_OF_YEAR) + 1);
		}
		c.set(Calendar.HOUR_OF_DAY, 8);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		horaDespertar = c.getTime();
		int tiempoRepeticion = 300000; 
		Timer temporizador = new Timer();
		if(temp.scheduledExecutionTime() != 0){
			
		}else{
			temporizador.scheduleAtFixedRate(temp, horaDespertar, tiempoRepeticion);
		}
			
	}
	
	public static String[] fechaHora(){
		String[] fechaHora = new String[2];
		
		Date fh = new Date();
		String fecha = fh.toString();
		String[] v = fecha.split(" ");
		switch(v[1]){	
			case "Jan": v[1] = "01";
				break;
			case "Feb": v[1] = "02";
				break;
			case "Mar": v[1] = "03";
				break;
			case "Apr": v[1] = "04";
				break;
			case "May": v[1] = "05";
				break;
			case "Jun": v[1] = "01";
				break;
			case "Jul": v[1] = "07";
				break;
			case "Aug": v[1] = "08";
				break;
			case "Sep": v[1] = "09";
				break;
			case "Oct": v[1] = "10";
				break;
			case "Nov": v[1] = "11";
				break;
			case "Dec": v[1] = "12";
				break;
		}
		fechaHora[0] = v[5]+v[1]+v[2];
		fechaHora[1] = v[3];
		
		return fechaHora;
	}
	public static String moverArchivo (String origin, String nombre, String destin){
		
		File origen = new File(origin + nombre);
	    File destino = new File(destin + "\\web\\descargas\\" +  nombre);
	    System.out.println("Ruta destino: " + destino);
	    try {
	    	InputStream in = new FileInputStream(origen);
	        OutputStream out = new FileOutputStream(destino);            
	        byte[] buf = new byte[1024];
	        int len;
	        while ((len = in.read(buf)) > 0) {
	        	out.write(buf, 0, len);
	        }
	        in.close();
	        out.close();
	     } catch (IOException e){
	    	 System.out.println("Error en moverArchivo");
	     }
	    return "\\web\\descargas\\" +  nombre;
	}
}