package clases;

import java.util.Calendar;
import java.util.TimerTask;
 
public class Temporizador extends TimerTask{

	@Override
	public void run() {
		
		Calendar diaActual = Calendar.getInstance();
		String hora = diaActual.get(Calendar.HOUR_OF_DAY) + "" + diaActual.get(Calendar.MINUTE) + "" + diaActual.get(Calendar.SECOND);
		
		String[] fechaHora = Metodos.fechaHora();
		String date = fechaHora[0];
		String hour = fechaHora[1];
		
		switch (Integer.parseInt(hora)) {
		
			case 8150:
				baseDatos.Sentencias.fichajeAutomatico(date, hour);
				break;
			case 9100:
				baseDatos.Sentencias.fichajeAutomatico(date, hour);
				break;
			case 10500:
				baseDatos.Sentencias.fichajeAutomatico(date, hour);
				break;
			case 11300:
				baseDatos.Sentencias.fichajeAutomatico(date, hour);
				break;
			case 12250:
				baseDatos.Sentencias.fichajeAutomatico(date, hour);
				break;
			case 13200:
				baseDatos.Sentencias.fichajeAutomatico(date, hour);
				break;
			
		}
	} 

}