package servlets;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AgregarCiclo extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		
		HttpSession paco = req.getSession();	
		ServletContext app = getServletContext();
		
		try{
			if(paco.getAttribute("dniProfesorSession") != null){
				String idCiclo = req.getParameter("idCiclo");
				String nombre = req.getParameter("nombre");
				String crear = req.getParameter("crear");
				String dni = (String) paco.getAttribute("dniProfesorSession");
				
				req.setAttribute("mensajeAgregearCiclo", "");
				if(crear != null){
					baseDatos.Sentencias.agregarCiclo(nombre, idCiclo, dni);
					req.setAttribute("mensajeAgregearCiclo", "Ciclo a�adido correctamente");
				}
				app.getRequestDispatcher("/WEB-INF/jsp/agregarCiclo.jsp").forward(req, resp);
				return;
			}else{
				req.setAttribute("mensajeError", "Error al gargar la pagina debido a que la sesion a ha caducado");
				app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
				return;
			}
		}catch(Exception e){
			req.setAttribute("mensajeError", "Error al gargar la pagina");
			app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
			return;
		}
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doGet(req, resp);
	}	
}