package servlets;

import java.io.IOException;
import java.net.InetAddress;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Alumno extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		
		HttpSession paco = req.getSession();
		ServletContext app = getServletContext();
		InetAddress direccion = InetAddress.getLocalHost();
		
		try{			
			String dni = req.getParameter("dni");
			String contrasena = req.getParameter("contrasena");
	
			paco.setAttribute("dniProfesorSession", dni);
			paco.setAttribute("contrasenaProfesorSession", contrasena);
			req.setAttribute("mensajeAlumno", "");
			
			if(paco.getAttribute("salir")!=null)
				paco.invalidate();
			if (dni == null){
				req.setAttribute("mensajeAlumno", "");
				app.getRequestDispatcher("/WEB-INF/jsp/alumno.jsp").forward(req, resp);
				return;
			}else{
								
				if(baseDatos.Sentencias.registroProfesores(dni, contrasena)){
					req.setAttribute("mensajeProfesor", "Bienvenido " + dni);
					req.setAttribute("dniProfesor", paco.getAttribute("dniProfesorSession"));
					paco.setAttribute("salir", "si");
					app.getRequestDispatcher("/WEB-INF/jsp/principal.jsp").forward(req, resp);
					return;	
				}else{
					if(baseDatos.Sentencias.registroAlumnos(dni, contrasena)){
						
						clases.Metodos.temp();
						
						String ip = direccion.getHostAddress();
						String[] fechaHora = clases.Metodos.fechaHora();
						String date = fechaHora[0];
						String hora = fechaHora[1];
						
						baseDatos.Sentencias.ficharAlumno(ip, date, hora, dni);
											
						req.setAttribute("mensajeAlumno", "Fichaje realizado con exito");
						app.getRequestDispatcher("/WEB-INF/jsp/alumno.jsp").forward(req, resp);
						return;
					}else{
						req.setAttribute("mensajeAlumno", "Login incorrecto");
						app.getRequestDispatcher("/WEB-INF/jsp/alumno.jsp").forward(req, resp);
						return;
					}		
				}
			}
		}catch(Exception e){
			req.setAttribute("mensajeError", "Error al cargar la pagina");
			app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
			return;
		}
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doGet(req, resp);
	}	
}