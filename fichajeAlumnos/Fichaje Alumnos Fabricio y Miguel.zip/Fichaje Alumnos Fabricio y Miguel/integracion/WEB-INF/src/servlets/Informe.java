package servlets;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Informe extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		
		ServletContext app = getServletContext();
		HttpSession paco = req.getSession();
		
		try{
			if(paco.getAttribute("dniProfesorSession") != null){
				req.setAttribute("dniProfesor", paco.getAttribute("dniProfesorSession"));
				req.setAttribute("idCiclo", paco.getAttribute("idCicloSession"));
				req.setAttribute("idModulo", paco.getAttribute("idModuloSession"));
				String fini = req.getParameter("fini");
				String ffin = req.getParameter("ffin");
				req.setAttribute("mensajeInforme", "");
				
				if(req.getParameter("generar") !=null && fini != null){
					fini = fini.replace("-", "");
					ffin = ffin.replace("-", "");
			        String ruta = getServletContext().getRealPath("/") + "/" + fini + ffin + paco.getAttribute("idModuloSession") + ".pdf";
			        baseDatos.Sentencias.generarInforme(fini, ffin, ruta);
				    req.setAttribute("mensajeInforme", "Informe generado correctamente");
				    req.setAttribute("ruta", "<h4 style='color: #369;'><a href='" + fini + ffin + paco.getAttribute("idModuloSession") + ".pdf" + "' download>Descargar informe</a></h4>");
				}
				app.getRequestDispatcher("/WEB-INF/jsp/informe.jsp").forward(req, resp);
				return;
				
			}else{
				req.setAttribute("mensajeError", "Error al cargar la pagina debido a que la sesion a ha caducado");
				app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
				return;
			}
		}catch(Exception e){
			req.setAttribute("mensajeError", "Error al gargar la pagina");
			app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
			return;
		}
			
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doGet(req, resp);
	}	
}