package servlets;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Lista extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {

		ServletContext app = getServletContext();
		HttpSession paco = req.getSession();
		
		try{
			if(paco.getAttribute("dniProfesorSession") != null){
				req.setAttribute("idCiclo", paco.getAttribute("idCicloSession"));
				req.setAttribute("idModulo", paco.getAttribute("idModuloSession"));
								
				app.getRequestDispatcher("/WEB-INF/jsp/lista.jsp").forward(req, resp);
				return;
			}else{
				req.setAttribute("mensajeError", "Error al cargar la pagina debido a que la sesion a ha caducado");
				app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
				return;
			}
		}catch(Exception e){
			req.setAttribute("mensajeError", "Error al cargar la pagina");
			app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
			return;
		}
	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doGet(req, resp);
	}	
}