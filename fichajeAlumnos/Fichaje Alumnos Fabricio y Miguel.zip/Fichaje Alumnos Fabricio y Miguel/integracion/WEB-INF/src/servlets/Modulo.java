package servlets;

import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Modulo extends HttpServlet{

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		
		ServletContext app = getServletContext();
		HttpSession paco = req.getSession();
		req.setAttribute("mensajeSubir","");
		try{
			if(paco.getAttribute("dniProfesorSession") != null){
				req.setAttribute("idCiclo", paco.getAttribute("idCicloSession"));
				req.setAttribute("idModulo", paco.getAttribute("idModuloSession"));
		
				if(req.getParameter("botonBorrar") != null){
					req.setAttribute("idCiclo", paco.getAttribute("idCicloSession"));
					if(baseDatos.Sentencias.eliminarModulo(paco.getAttribute("idModuloSession").toString())){
						app.getRequestDispatcher("/WEB-INF/jsp/ciclo.jsp").forward(req, resp);
						return;
					}
				}else{
					if(req.getAttribute("idCiclo") != null){
						app.getRequestDispatcher("/WEB-INF/jsp/modulo.jsp").forward(req, resp);
						return;
					}else{
						app.getRequestDispatcher("/WEB-INF/jsp/ciclo.jsp").forward(req, resp);
						return;
					}
				}
			}else{
				req.setAttribute("mensajeError", "Error al cargar la pagina debido a que la sesion a ha caducado");
				app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
				return;
			}
		}catch(Exception e){
			req.setAttribute("mensajeError", "Error al gargar la pagina");
			app.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
			return;
		}
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
		throws ServletException, IOException {
		doGet(req, resp);
	}	
}