$(document).ready(function(){
	$(".ciclo").on('click', function(){
		var idCiclo = $(this).text();
		$.get('profesor.do', {'idCiclo': idCiclo}); 
	});
	
	$(".modulo").on('click', function(){
		var idModulo = $(this).text();
		$.get('ciclo.do', {'idModulo': idModulo}); 
	});
	
	$("#eliminar").on('click', function(){
		$.get('ciclo.do', {'botonEliminar': "si"}); 
	});
	$("#borrar").on('click', function(){
		$.get('modulo.do', {'botonBorrar': "si"}); 
	});
	
	$('.menu-anchor').on('click touchstart', function(e){
		$('html').toggleClass('menu-active');
	  	e.preventDefault();
	});
	$('.menu-icon').click(function () {
		if ($('#navigator').css("left") == "-250px") {
			$('#navigator').animate({left: '0px'}, 350);
	        $('.menu-icon').animate({left: '250px'}, 350);
	        $('.menu-text').animate({left: '300px'}, 350).empty().text("Cerrar");
	    }else{
	    	$('#navigator').animate({left: '-250px'}, 350); 
	        $(this).animate({left: '0px'}, 350);
	        $('.menu-text').animate({left: '50px'}, 350).empty().text("Menu");
	    } 
	});
	$('.menu-icon').click(function () {
		$(this).toggleClass("on"); 
	});
});